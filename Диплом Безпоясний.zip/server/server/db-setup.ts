import { db } from "./db";
import { 
  products, 
  categories, 
  suppliers, 
  evaluationHistory 
} from "@shared/schema";
import { SQL, sql } from "drizzle-orm";

async function setupDatabase() {
  try {
    console.log("Starting database setup...");
    
    // Drop existing tables to ensure clean setup (comment out in production)
    await db.execute(sql`DROP TABLE IF EXISTS evaluation_history CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS products CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS categories CASCADE`);
    await db.execute(sql`DROP TABLE IF EXISTS suppliers CASCADE`);

    // Create tables (normally handled by drizzle migration, but for demo purposes)
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL UNIQUE,
        description TEXT
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS suppliers (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        rating NUMERIC(3,1),
        contact_info TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        category_id INTEGER NOT NULL REFERENCES categories(id),
        brand TEXT NOT NULL,
        year INTEGER,
        condition TEXT,
        supplier_id INTEGER REFERENCES suppliers(id),
        description TEXT,
        price NUMERIC(10,2),
        features JSONB,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS evaluation_history (
        id SERIAL PRIMARY KEY,
        product_name TEXT,
        category TEXT NOT NULL,
        brand TEXT NOT NULL,
        year INTEGER,
        condition TEXT,
        supplier_id INTEGER,
        description TEXT,
        estimated_price NUMERIC(10,2),
        comparisons INTEGER NOT NULL,
        status TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);

    // Check if categories already exist
    const existingCategories = await db.select().from(categories);
    
    if (existingCategories.length === 0) {
      console.log("Inserting categories...");
      // Insert categories
      await db.insert(categories).values([
        { name: "Електроніка", description: "Смартфони, ноутбуки, телевізори та інша електроніка" },
        { name: "Одяг", description: "Одяг для чоловіків, жінок та дітей" },
        { name: "Спортивні товари", description: "Спортивний інвентар та спортивний одяг" },
        { name: "Меблі", description: "Меблі для дому та офісу" },
        { name: "Побутова техніка", description: "Техніка для дому та кухні" },
        { name: "Інструменти", description: "Будівельні та садові інструменти" }
      ]);
    }

    // Check if suppliers already exist
    const existingSuppliers = await db.select().from(suppliers);
    
    if (existingSuppliers.length === 0) {
      console.log("Inserting suppliers...");
      // Insert suppliers
      await db.insert(suppliers).values([
        { name: "ElectroMax", rating: 4.8, contactInfo: "contact@electromax.com" },
        { name: "SportLife", rating: 4.5, contactInfo: "info@sportlife.com" },
        { name: "HomeTech", rating: 4.2, contactInfo: "support@hometech.com" },
        { name: "FashionStyle", rating: 4.7, contactInfo: "orders@fashionstyle.com" },
        { name: "ToolMaster", rating: 4.0, contactInfo: "sales@toolmaster.com" }
      ]);
    }

    // Get category IDs for reference
    const categoryList = await db.select().from(categories);
    const categoryMap = new Map(categoryList.map(cat => [cat.name, cat.id]));
    
    // Get supplier IDs for reference
    const supplierList = await db.select().from(suppliers);
    const supplierMap = new Map(supplierList.map(sup => [sup.name, sup.id]));

    // Check if products already exist
    const existingProducts = await db.select().from(products);
    
    if (existingProducts.length === 0) {
      console.log("Inserting products...");
      // Insert products
      await db.insert(products).values([
        {
          name: 'Samsung Galaxy S10',
          categoryId: categoryMap.get('Електроніка') || 1,
          brand: 'Samsung',
          year: 2019,
          condition: 'used',
          supplierId: supplierMap.get('ElectroMax') || 1,
          description: 'Smartphone 2019',
          price: '400.00',
          features: JSON.stringify(['6.1" display', '8GB RAM', '128GB storage'])
        },
        {
          name: 'Samsung Galaxy S20',
          categoryId: categoryMap.get('Електроніка') || 1,
          brand: 'Samsung',
          year: 2020,
          condition: 'used',
          supplierId: supplierMap.get('ElectroMax') || 1,
          description: 'Smartphone 2020',
          price: '500.00',
          features: JSON.stringify(['6.2" display', '8GB RAM', '128GB storage'])
        },
        {
          name: 'iPhone 11',
          categoryId: categoryMap.get('Електроніка') || 1,
          brand: 'Apple',
          year: 2019,
          condition: 'used',
          supplierId: supplierMap.get('ElectroMax') || 1,
          description: 'Smartphone 2019',
          price: '450.00',
          features: JSON.stringify(['6.1" display', '4GB RAM', '64GB storage'])
        },
        {
          name: 'Sony TV X120',
          categoryId: categoryMap.get('Електроніка') || 1,
          brand: 'Sony',
          year: 2018,
          condition: 'new',
          supplierId: supplierMap.get('HomeTech') || 3,
          description: 'Television 2018',
          price: '800.00',
          features: JSON.stringify(['55" 4K', 'HDR', 'Smart TV'])
        },
        {
          name: 'Nike Running Shoes',
          categoryId: categoryMap.get('Спортивні товари') || 3,
          brand: 'Nike',
          year: 2021,
          condition: 'new',
          supplierId: supplierMap.get('SportLife') || 2,
          description: 'Running shoes',
          price: '100.00',
          features: JSON.stringify(['Lightweight', 'Breathable', 'Size 42'])
        },
        {
          name: 'Adidas Running Shoes',
          categoryId: categoryMap.get('Спортивні товари') || 3,
          brand: 'Adidas',
          year: 2020,
          condition: 'used',
          supplierId: supplierMap.get('SportLife') || 2,
          description: 'Running shoes',
          price: '80.00',
          features: JSON.stringify(['Comfortable', 'Durable', 'Size 43'])
        },
        {
          name: 'IKEA Desk',
          categoryId: categoryMap.get('Меблі') || 4,
          brand: 'IKEA',
          year: 2022,
          condition: 'new',
          supplierId: supplierMap.get('HomeTech') || 3,
          description: 'Computer desk',
          price: '120.00',
          features: JSON.stringify(['120x60 cm', 'White', 'Adjustable height'])
        },
        {
          name: 'Bosch Drill',
          categoryId: categoryMap.get('Інструменти') || 6,
          brand: 'Bosch',
          year: 2021,
          condition: 'new',
          supplierId: supplierMap.get('ToolMaster') || 5,
          description: 'Electric drill',
          price: '150.00',
          features: JSON.stringify(['800W', 'Cordless', '2 batteries'])
        },
        {
          name: 'Zara Jacket',
          categoryId: categoryMap.get('Одяг') || 2,
          brand: 'Zara',
          year: 2023,
          condition: 'new',
          supplierId: supplierMap.get('FashionStyle') || 4,
          description: 'Men\'s jacket',
          price: '70.00',
          features: JSON.stringify(['Size L', 'Black', 'Waterproof'])
        }
      ]);
    }
    
    console.log("Database setup completed successfully!");
  } catch (error) {
    console.error("Database setup error:", error);
  }
}

// Execute the script
setupDatabase().then(() => {
  console.log("Setup done!");
  process.exit(0);
}).catch(err => {
  console.error("Setup failed:", err);
  process.exit(1);
});