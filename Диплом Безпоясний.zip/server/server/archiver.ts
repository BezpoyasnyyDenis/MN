import archiver from 'archiver';
import fs from 'fs';
import path from 'path';
import { promises as fsPromises } from 'fs';
import os from 'os';
import { fileURLToPath } from 'url';

// Get current directory path
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

/**
 * Create a ZIP archive of the project source code
 * @returns Path to the generated archive file
 */
export async function createArchive(): Promise<string> {
  // Create temporary file for the archive
  const tempDir = os.tmpdir();
  const archivePath = path.join(tempDir, `product-estimation-source-${Date.now()}.zip`);
  
  // Create output stream to write the archive
  const output = fs.createWriteStream(archivePath);
  const archive = archiver('zip', {
    zlib: { level: 9 } // Maximum compression
  });

  // Handle archive completion
  const archivePromise = new Promise<string>((resolve, reject) => {
    output.on('close', () => {
      console.log(`Archive created: ${archivePath}, size: ${archive.pointer()} bytes`);
      resolve(archivePath);
    });

    archive.on('error', (err) => {
      reject(err);
    });
  });

  // Pipe archive data to output file
  archive.pipe(output);

  // Add frontend code
  archive.directory(path.resolve(__dirname, '../client'), 'client');
  
  // Add server code
  archive.directory(path.resolve(__dirname, '..'), 'server', (entryData) => {
    // Exclude node_modules and dist directories
    const name = entryData.name;
    if (
      name.includes('node_modules') || 
      name.includes('dist') || 
      name.includes('.git')
    ) {
      return false;
    }
    return entryData;
  });
  
  // Add SQL file for database setup
  const schemaContent = generateSchemaSQL();
  archive.append(schemaContent, { name: 'schema.sql' });
  
  // Add README file with setup instructions
  const readmeContent = generateReadme();
  archive.append(readmeContent, { name: 'README.md' });
  
  // Finalize archive
  await archive.finalize();
  
  return archivePromise;
}

/**
 * Generate SQL schema file content
 */
function generateSchemaSQL(): string {
  return `-- schema.sql
-- Create database and products table

CREATE TABLE IF NOT EXISTS products (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    brand TEXT NOT NULL,
    year INT,
    condition TEXT,
    description TEXT,
    price NUMERIC(10,2),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sample data for products
INSERT INTO products (name, category, brand, year, condition, description, price) VALUES
('Samsung Galaxy S10', 'Electronics', 'Samsung', 2019, 'used', 'Smartphone 2019', 400.00),
('Samsung Galaxy S20', 'Electronics', 'Samsung', 2020, 'used', 'Smartphone 2020', 500.00),
('iPhone 11', 'Electronics', 'Apple', 2019, 'used', 'Smartphone 2019', 450.00),
('Sony TV X120', 'Electronics', 'Sony', 2018, 'new', 'Television 2018', 800.00),
('Nike Running Shoes', 'Sportswear', 'Nike', 2021, 'new', 'Running shoes', 100.00),
('Adidas Running Shoes', 'Sportswear', 'Adidas', 2020, 'used', 'Running shoes', 80.00);
`;
}

/**
 * Generate README file content
 */
function generateReadme(): string {
  return `# Product Price Estimation System

This project is a web application for estimating product prices based on comparison with similar products in a database.

## Features

- Product price estimation based on database comparison
- Form to input product details (category, brand, year, condition, etc.)
- Backend API to calculate estimated price
- PostgreSQL database integration

## Project Structure

\`\`\`
project-root/
├─ client/           # React frontend
│  ├─ public/
│  ├─ src/
│  │  ├─ components/ # React components
│  │  ├─ lib/        # Utility functions
│  │  └─ pages/      # Pages for routing
├─ server/           # Node.js backend
│  ├─ db.ts          # Database connection
│  ├─ routes.ts      # API endpoints
│  ├─ storage.ts     # Database operations
│  └─ index.ts       # Server setup
└─ schema.sql        # SQL schema for database
\`\`\`

## Setup Instructions

### Prerequisites

- Node.js (v14 or higher)
- PostgreSQL database

### Database Setup

1. Create a new PostgreSQL database
2. Run the provided \`schema.sql\` file to create the table and sample data:
   \`\`\`
   psql -U youruser -d yourdb -f schema.sql
   \`\`\`

### Environment Variables

Create a \`.env\` file with the following variables:

\`\`\`
DATABASE_URL=postgresql://username:password@localhost:5432/yourdb
\`\`\`

### Installation

1. Install dependencies:
   \`\`\`
   npm install
   \`\`\`

2. Start the development server:
   \`\`\`
   npm run dev
   \`\`\`

## API Documentation

### POST /api/evaluate

Evaluates the price of a product based on similar products in the database.

**Request Body:**

\`\`\`json
{
  "name": "Product Name",
  "category": "Category", // required
  "brand": "Brand",      // required
  "year": 2023,          // optional
  "condition": "new",    // optional
  "description": "Description" // optional
}
\`\`\`

**Response:**

\`\`\`json
{
  "estimatedPrice": "450.00",
  "comparisons": 2
}
\`\`\`

## License

This project is available as open source under the terms of the MIT License.
`;
}
