import { 
  users, type User, type InsertUser, 
  products, type Product, type InsertProduct, type ProductEvaluation,
  categories, type Category,
  suppliers, type Supplier,
  evaluationHistory, type EvaluationHistory, type InsertEvaluationHistory
} from "@shared/schema";
import { db } from "./db";
import { eq, and, sql, like, desc, asc } from "drizzle-orm";

// Interface for storage operations
export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Category operations
  getCategories(): Promise<Category[]>;
  getCategory(id: number): Promise<Category | undefined>;
  
  // Supplier operations
  getSuppliers(): Promise<Supplier[]>;
  getSupplier(id: number): Promise<Supplier | undefined>;
  
  // Product operations
  getProducts(): Promise<Product[]>;
  getProductsByCategory(categoryId: number): Promise<Product[]>;
  getProductsBySupplier(supplierId: number): Promise<Product[]>;
  getProduct(id: number): Promise<Product | undefined>;
  createProduct(product: InsertProduct): Promise<Product>;
  
  // Evaluation operations
  evaluateProductPrice(evaluation: ProductEvaluation): Promise<{ estimatedPrice: number | null, count: number }>;
  saveEvaluationHistory(history: InsertEvaluationHistory): Promise<EvaluationHistory>;
  getEvaluationHistory(limit?: number): Promise<EvaluationHistory[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations implementation
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Category operations
  async getCategories(): Promise<Category[]> {
    return await db.select().from(categories);
  }

  async getCategory(id: number): Promise<Category | undefined> {
    const [category] = await db.select().from(categories).where(eq(categories.id, id));
    return category || undefined;
  }

  // Supplier operations
  async getSuppliers(): Promise<Supplier[]> {
    return await db.select().from(suppliers).orderBy(desc(suppliers.rating));
  }

  async getSupplier(id: number): Promise<Supplier | undefined> {
    const [supplier] = await db.select().from(suppliers).where(eq(suppliers.id, id));
    return supplier || undefined;
  }

  // Product operations implementation
  async getProducts(): Promise<Product[]> {
    return await db.select().from(products);
  }

  async getProductsByCategory(categoryId: number): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.categoryId, categoryId));
  }

  async getProductsBySupplier(supplierId: number): Promise<Product[]> {
    return await db.select().from(products).where(eq(products.supplierId, supplierId));
  }

  async getProduct(id: number): Promise<Product | undefined> {
    const [product] = await db.select().from(products).where(eq(products.id, id));
    return product || undefined;
  }

  async createProduct(product: InsertProduct): Promise<Product> {
    const [newProduct] = await db.insert(products).values(product).returning();
    return newProduct;
  }

  // Evaluation operations
  async evaluateProductPrice(evaluation: ProductEvaluation): Promise<{ estimatedPrice: number | null, count: number }> {
    try {
      // Build query to find similar products
      let query = db.select({
        avgPrice: sql<string>`AVG(${products.price})`,
        count: sql<string>`COUNT(*)`
      }).from(products);

      // Add filters based on the provided evaluation data
      const mandatoryConditions = [];
      const optionalConditions = [];

      // Get category ID from category name - category is mandatory
      if (evaluation.category) {
        const [category] = await db.select()
          .from(categories)
          .where(like(categories.name, evaluation.category));
        
        if (category) {
          mandatoryConditions.push(eq(products.categoryId, category.id));
        } else {
          // No matching category found
          console.log(`No matching category found for: ${evaluation.category}`);
          return { estimatedPrice: null, count: 0 };
        }
      }

      // Brand is mandatory
      if (evaluation.brand) {
        mandatoryConditions.push(eq(products.brand, evaluation.brand));
      } else {
        console.log("Brand is required but not provided");
        return { estimatedPrice: null, count: 0 };
      }

      // Try with mandatory conditions first
      let allConditions = [...mandatoryConditions];
      
      // Add optional filters
      if (evaluation.year) {
        optionalConditions.push(eq(products.year, evaluation.year));
      }
      
      if (evaluation.condition) {
        optionalConditions.push(eq(products.condition, evaluation.condition));
      }

      if (evaluation.supplierId) {
        optionalConditions.push(eq(products.supplierId, evaluation.supplierId));
      }

      // First try with all conditions (mandatory + optional)
      if (optionalConditions.length > 0) {
        allConditions = [...mandatoryConditions, ...optionalConditions];
      }

      // Apply all conditions
      if (allConditions.length > 0) {
        query = query.where(and(...allConditions));
      }

      // Execute query with all filters
      const resultWithAllFilters = await query;
      
      // Parse results
      let avgPrice = resultWithAllFilters[0]?.avgPrice ? parseFloat(resultWithAllFilters[0].avgPrice) : null;
      let count = resultWithAllFilters[0]?.count ? parseInt(resultWithAllFilters[0].count) : 0;

      // If no results found with all filters, try with only mandatory filters
      if (count === 0 && optionalConditions.length > 0) {
        console.log("No results with all filters, trying with only mandatory filters");
        
        // Rebuild query with only mandatory conditions
        query = db.select({
          avgPrice: sql<string>`AVG(${products.price})`,
          count: sql<string>`COUNT(*)`
        }).from(products).where(and(...mandatoryConditions));
        
        const resultWithMandatoryFilters = await query;
        
        avgPrice = resultWithMandatoryFilters[0]?.avgPrice ? parseFloat(resultWithMandatoryFilters[0].avgPrice) : null;
        count = resultWithMandatoryFilters[0]?.count ? parseInt(resultWithMandatoryFilters[0].count) : 0;
      }

      // Still no results, try even more relaxed search
      if (count === 0 && mandatoryConditions.length >= 2) {
        console.log("No results with mandatory filters, trying with category only");
        
        // Try with only category condition
        query = db.select({
          avgPrice: sql<string>`AVG(${products.price})`,
          count: sql<string>`COUNT(*)`
        }).from(products).where(mandatoryConditions[0]); // Use only the category filter
        
        const resultWithCategoryOnly = await query;
        
        avgPrice = resultWithCategoryOnly[0]?.avgPrice ? parseFloat(resultWithCategoryOnly[0].avgPrice) : null;
        count = resultWithCategoryOnly[0]?.count ? parseInt(resultWithCategoryOnly[0].count) : 0;
      }

      console.log(`Evaluation result: price=${avgPrice}, count=${count}`);
      return { 
        estimatedPrice: avgPrice, 
        count 
      };
    } catch (error) {
      console.error("Error during price evaluation:", error);
      return { estimatedPrice: null, count: 0 };
    }
  }

  // Evaluation history operations
  async saveEvaluationHistory(history: InsertEvaluationHistory): Promise<EvaluationHistory> {
    const [record] = await db.insert(evaluationHistory).values(history).returning();
    return record;
  }

  async getEvaluationHistory(limit = 10): Promise<EvaluationHistory[]> {
    return await db.select()
      .from(evaluationHistory)
      .orderBy(desc(evaluationHistory.createdAt))
      .limit(limit);
  }
}

// Export database storage implementation
export const storage = new DatabaseStorage();
