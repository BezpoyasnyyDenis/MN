import { db } from "./db";
import { products } from "@shared/schema";

async function migrate() {
  try {
    console.log("Starting database migration...");
    
    // Check if there are any products in the database already
    const existingProducts = await db.select().from(products);
    
    if (existingProducts.length > 0) {
      console.log(`Database already has ${existingProducts.length} products. Skipping sample data insertion.`);
      return;
    }
    
    console.log("Inserting sample data...");
    
    // Sample product data
    const sampleProducts = [
      {
        name: 'Samsung Galaxy S10',
        category: 'Electronics',
        brand: 'Samsung',
        year: 2019,
        condition: 'used',
        description: 'Smartphone 2019',
        price: '400.00'
      },
      {
        name: 'Samsung Galaxy S20',
        category: 'Electronics',
        brand: 'Samsung',
        year: 2020,
        condition: 'used',
        description: 'Smartphone 2020',
        price: '500.00'
      },
      {
        name: 'iPhone 11',
        category: 'Electronics',
        brand: 'Apple',
        year: 2019,
        condition: 'used',
        description: 'Smartphone 2019',
        price: '450.00'
      },
      {
        name: 'Sony TV X120',
        category: 'Electronics',
        brand: 'Sony',
        year: 2018,
        condition: 'new',
        description: 'Television 2018',
        price: '800.00'
      },
      {
        name: 'Nike Running Shoes',
        category: 'Sportswear',
        brand: 'Nike',
        year: 2021,
        condition: 'new',
        description: 'Running shoes',
        price: '100.00'
      },
      {
        name: 'Adidas Running Shoes',
        category: 'Sportswear',
        brand: 'Adidas',
        year: 2020,
        condition: 'used',
        description: 'Running shoes',
        price: '80.00'
      }
    ];
    
    // Insert products into the database
    await db.insert(products).values(sampleProducts);
    
    console.log(`Successfully inserted ${sampleProducts.length} sample products.`);
  } catch (error) {
    console.error("Migration error:", error);
  }
}

// Execute the migration script
migrate().then(() => {
  console.log("Migration completed!");
  process.exit(0);
}).catch(err => {
  console.error("Migration failed:", err);
  process.exit(1);
});