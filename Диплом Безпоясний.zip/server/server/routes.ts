import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { z } from "zod";
import { productEvaluationSchema, conditionEnum } from "@shared/schema";
import { ZodError } from "zod";
import { createArchive } from "./archiver";
import path from "path";

export async function registerRoutes(app: Express): Promise<Server> {
  // API route for getting categories
  app.get("/api/categories", async (_req: Request, res: Response) => {
    try {
      const categories = await storage.getCategories();
      return res.json(categories);
    } catch (error) {
      console.error("Error fetching categories:", error);
      return res.status(500).json({ 
        error: "Failed to fetch categories" 
      });
    }
  });

  // API route for getting suppliers
  app.get("/api/suppliers", async (_req: Request, res: Response) => {
    try {
      const suppliers = await storage.getSuppliers();
      return res.json(suppliers);
    } catch (error) {
      console.error("Error fetching suppliers:", error);
      return res.status(500).json({ 
        error: "Failed to fetch suppliers" 
      });
    }
  });

  // API route for getting condition options
  app.get("/api/conditions", async (_req: Request, res: Response) => {
    try {
      // Return the available conditions from the enum
      return res.json(conditionEnum.options);
    } catch (error) {
      console.error("Error fetching conditions:", error);
      return res.status(500).json({ 
        error: "Failed to fetch conditions" 
      });
    }
  });

  // API route for evaluating product price
  app.post("/api/evaluate", async (req: Request, res: Response) => {
    try {
      // Validate request body using Zod schema
      const evaluation = productEvaluationSchema.parse(req.body);

      // Calculate estimated price
      const result = await storage.evaluateProductPrice(evaluation);

      if (result.count === 0 || result.estimatedPrice === null) {
        // Save evaluation history with failure status
        await storage.saveEvaluationHistory({
          productName: evaluation.name || '',
          category: evaluation.category,
          brand: evaluation.brand,
          year: evaluation.year || null,
          condition: evaluation.condition || null,
          supplierId: evaluation.supplierId || null,
          description: evaluation.description || null,
          estimatedPrice: null,
          comparisons: 0,
          status: 'no_matches'
        });

        return res.status(404).json({ 
          message: "No similar products found for evaluation." 
        });
      }

      // Save evaluation history with success status
      await storage.saveEvaluationHistory({
        productName: evaluation.name || '',
        category: evaluation.category,
        brand: evaluation.brand,
        year: evaluation.year || null,
        condition: evaluation.condition || null,
        supplierId: evaluation.supplierId || null,
        description: evaluation.description || null,
        estimatedPrice: result.estimatedPrice.toString(),
        comparisons: result.count,
        status: 'success'
      });

      // Return successful response
      return res.json({
        estimatedPrice: result.estimatedPrice.toFixed(2),
        comparisons: result.count
      });
    } catch (error) {
      // Handle validation errors
      if (error instanceof ZodError) {
        const validationErrors = error.errors.map(err => ({
          field: err.path.join('.'),
          message: err.message
        }));
        
        return res.status(400).json({ 
          error: "Validation Error", 
          details: validationErrors 
        });
      }

      // Handle other errors
      console.error("Error evaluating product price:", error);
      
      // Try to save evaluation history with error status if possible
      try {
        if (req.body && typeof req.body === 'object') {
          await storage.saveEvaluationHistory({
            productName: req.body.name || '',
            category: req.body.category || 'Unknown',
            brand: req.body.brand || 'Unknown',
            year: req.body.year || null,
            condition: req.body.condition || null,
            supplierId: req.body.supplierId || null,
            description: req.body.description || null,
            estimatedPrice: null,
            comparisons: 0,
            status: 'error'
          });
        }
      } catch (historyError) {
        console.error("Failed to save evaluation error history:", historyError);
      }

      return res.status(500).json({ 
        error: "Internal server error" 
      });
    }
  });

  // API route for getting evaluation history
  app.get("/api/evaluation-history", async (_req: Request, res: Response) => {
    try {
      const history = await storage.getEvaluationHistory(20); // Get last 20 evaluations
      return res.json(history);
    } catch (error) {
      console.error("Error fetching evaluation history:", error);
      return res.status(500).json({ 
        error: "Failed to fetch evaluation history" 
      });
    }
  });

  // API route for generating and downloading source code archive
  app.get("/api/download-code", async (_req: Request, res: Response) => {
    try {
      // Generate the code archive
      const archivePath = await createArchive();
      
      // Determine filename
      const filename = path.basename(archivePath);
      
      // Set appropriate headers for download
      res.setHeader('Content-Disposition', `attachment; filename=${filename}`);
      res.setHeader('Content-Type', 'application/zip');
      
      // Send the file
      return res.sendFile(archivePath);
    } catch (error) {
      console.error("Error creating code archive:", error);
      return res.status(500).json({ 
        error: "Failed to generate code archive" 
      });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
