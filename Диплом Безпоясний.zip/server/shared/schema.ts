import { pgTable, text, serial, integer, numeric, timestamp, json, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Original users schema (keep this as it might be used elsewhere)
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Categories table for product categories
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
});

export const categoriesRelations = relations(categories, ({ many }) => ({
  products: many(products),
}));

// Suppliers table for product suppliers
export const suppliers = pgTable("suppliers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  rating: numeric("rating", { precision: 3, scale: 1 }),
  contactInfo: text("contact_info"),
  createdAt: timestamp("created_at").defaultNow()
});

// Product condition enum for better type safety
export const conditionEnum = z.enum(["new", "used", "refurbished", "damaged"]);
export type ConditionType = z.infer<typeof conditionEnum>;

// Products schema enhanced with additional fields
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  categoryId: integer("category_id").notNull(),
  brand: text("brand").notNull(),
  year: integer("year"),
  condition: text("condition"),
  supplierId: integer("supplier_id"),
  description: text("description"),
  price: numeric("price", { precision: 10, scale: 2 }),
  features: json("features").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow()
});

// Relations for products table
export const productsRelations = relations(products, ({ one }) => ({
  category: one(categories, {
    fields: [products.categoryId],
    references: [categories.id],
  }),
  supplier: one(suppliers, {
    fields: [products.supplierId],
    references: [suppliers.id],
  }),
}));

// Evaluation history to track product evaluations
export const evaluationHistory = pgTable("evaluation_history", {
  id: serial("id").primaryKey(),
  productName: text("product_name"),
  category: text("category").notNull(),
  brand: text("brand").notNull(),
  year: integer("year"),
  condition: text("condition"),
  supplierId: integer("supplier_id"),
  description: text("description"),
  estimatedPrice: numeric("estimated_price", { precision: 10, scale: 2 }),
  comparisons: integer("comparisons").notNull(),
  status: text("status").notNull(), // Success, No matches, Error
  createdAt: timestamp("created_at").defaultNow()
});

// Schema for creating products
export const insertProductSchema = createInsertSchema(products).omit({
  id: true,
  createdAt: true
});

// Schema for evaluation history
export const insertEvaluationHistorySchema = createInsertSchema(evaluationHistory).omit({
  id: true,
  createdAt: true
});

// Schema for product evaluation (input form)
export const productEvaluationSchema = z.object({
  name: z.string().optional(),
  category: z.string().min(1, "Категорія є обов'язковою"),
  brand: z.string().min(1, "Бренд є обов'язковим"),
  year: z.coerce.number().optional().nullable(),
  condition: conditionEnum.optional(),
  supplierId: z.coerce.number().optional().nullable(),
  description: z.string().optional(),
  features: z.array(z.string()).optional()
});

// Type definitions
export type InsertProduct = z.infer<typeof insertProductSchema>;
export type Product = typeof products.$inferSelect;
export type ProductEvaluation = z.infer<typeof productEvaluationSchema>;
export type InsertEvaluationHistory = z.infer<typeof insertEvaluationHistorySchema>;
export type EvaluationHistory = typeof evaluationHistory.$inferSelect;
export type Category = typeof categories.$inferSelect;
export type Supplier = typeof suppliers.$inferSelect;
