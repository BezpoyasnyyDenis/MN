import { useState } from "react";
import { useLocation } from "wouter";
import ProductForm from "@/components/product-form";
import ResultDisplay from "@/components/result-display";
import Navigation from "@/components/navigation";
import EvaluationHistory from "@/components/evaluation-history";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { DownloadCloud, Sparkles, History, Gauge } from "lucide-react";
import { ProductEvaluation, EvaluationResult } from "@/lib/utils";

export default function PriceEstimation() {
  const [result, setResult] = useState<EvaluationResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState("evaluation");

  const handleEvaluationResult = (data: EvaluationResult) => {
    setResult(data);
    setError(null);
  };

  const handleEvaluationError = (message: string) => {
    setError(message);
    setResult(null);
  };

  const [, navigate] = useLocation();

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-gray-100">
      {/* Header Section */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-semibold text-gray-800 flex items-center">
              <Sparkles className="h-6 w-6 mr-2 text-primary" />
              Оцінка вартості товару
            </h1>
            <button 
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-gradient-to-r from-primary to-primary-dark hover:from-primary/90 hover:to-primary-dark/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary transition-all duration-200"
              onClick={() => navigate("/download")}
            >
              <DownloadCloud className="h-5 w-5 mr-2" />
              Завантажити код
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <Navigation activeTab="estimation" />
        
        <div className="mb-6 mt-8">
          <Tabs defaultValue="evaluation" value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full max-w-md mx-auto grid-cols-2">
              <TabsTrigger value="evaluation" className="flex items-center">
                <Gauge className="h-4 w-4 mr-2" /> 
                Оцінка товару
              </TabsTrigger>
              <TabsTrigger value="history" className="flex items-center">
                <History className="h-4 w-4 mr-2" /> 
                Історія оцінювань
              </TabsTrigger>
            </TabsList>
            <Separator className="my-6" />
            
            <TabsContent value="evaluation">
              <div className="flex flex-col md:flex-row gap-8">
                {/* Product Form */}
                <div className="md:w-7/12">
                  <ProductForm 
                    onResult={handleEvaluationResult} 
                    onError={handleEvaluationError}
                    setLoading={setLoading}
                  />
                </div>
                
                {/* Result Display */}
                <div className="md:w-5/12">
                  <ResultDisplay 
                    result={result} 
                    error={error}
                    loading={loading}
                  />
                </div>
              </div>
            </TabsContent>
            
            <TabsContent value="history">
              <EvaluationHistory />
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 border-t border-gray-200">
          <p className="text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Оцінка вартості товару. Усі права захищено.
          </p>
        </div>
      </footer>
    </div>
  );
}
