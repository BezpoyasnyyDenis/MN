import { useState } from "react";
import { useLocation } from "wouter";
import Navigation from "@/components/navigation";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { downloadSourceCode } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { Check, Download, Zap, Server } from "lucide-react";

export default function DownloadCode() {
  const [downloading, setDownloading] = useState(false);
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const handleDownload = async () => {
    try {
      setDownloading(true);
      await downloadSourceCode();
      toast({
        title: "Завантаження розпочато",
        description: "Файл з кодом проекту почав завантажуватись",
        variant: "default",
      });
    } catch (error) {
      toast({
        title: "Помилка завантаження",
        description: "Не вдалося завантажити код. Спробуйте пізніше.",
        variant: "destructive",
      });
      console.error("Download error:", error);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header Section */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-semibold text-gray-800">Оцінка вартості товару</h1>
            <button 
              onClick={() => navigate("/")}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-gray-700 bg-gray-100 hover:bg-gray-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
            >
              Повернутись до оцінки
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Tab Navigation */}
        <Navigation activeTab="download" />

        {/* Download Section */}
        <div id="download-section" className="mt-6">
          <Card>
            <CardContent className="p-6">
              <h2 className="text-lg font-medium text-gray-900 mb-6">Завантаження вихідного коду</h2>
              
              <div className="bg-gray-50 p-4 rounded-lg border border-gray-200 mb-6">
                <h3 className="text-base font-medium text-gray-800 mb-3">Що включено в архів:</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-sm text-gray-600">
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    React-компоненти для форми введення
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    Express сервер з API-маршрутами
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    SQL-скрипт для створення БД
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    Код підключення до PostgreSQL
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    Повна документація з інструкцією
                  </li>
                  <li className="flex items-start">
                    <Check className="h-5 w-5 mr-2 text-green-500" />
                    Приклади запитів/відповідей
                  </li>
                </ul>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Структура проекту</h3>
                    <div className="mt-2 text-sm text-gray-500 space-y-1 font-mono">
                      <p>project-root/</p>
                      <p>├─ client/</p>
                      <p>│  ├─ public/</p>
                      <p>│  ├─ src/</p>
                      <p>│  │  ├─ components/</p>
                      <p>│  │  └─ App.tsx</p>
                      <p>│  └─ package.json</p>
                      <p>├─ server/</p>
                      <p>│  ├─ db.ts</p>
                      <p>│  ├─ routes.ts</p>
                      <p>│  └─ storage.ts</p>
                      <p>└─ schema.sql</p>
                    </div>
                  </div>
                </div>
                
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <div className="px-4 py-5 sm:p-6">
                    <h3 className="text-lg leading-6 font-medium text-gray-900">Технічні деталі</h3>
                    <div className="mt-5">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 h-8 w-8 flex items-center justify-center rounded-md bg-blue-500 text-white">
                          <Zap className="h-5 w-5" />
                        </div>
                        <div className="ml-4">
                          <h4 className="text-sm font-medium text-gray-900">Фронтенд</h4>
                          <p className="text-sm text-gray-500">React, TypeScript, Tailwind CSS</p>
                        </div>
                      </div>
                      <div className="mt-4 flex items-center">
                        <div className="flex-shrink-0 h-8 w-8 flex items-center justify-center rounded-md bg-green-500 text-white">
                          <Server className="h-5 w-5" />
                        </div>
                        <div className="ml-4">
                          <h4 className="text-sm font-medium text-gray-900">Бекенд</h4>
                          <p className="text-sm text-gray-500">Node.js, Express, PostgreSQL</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="mt-8 text-center">
                <Button 
                  onClick={handleDownload} 
                  disabled={downloading}
                  size="lg"
                  className="inline-flex items-center px-6 py-3 text-base"
                >
                  <Download className="h-5 w-5 mr-2" />
                  {downloading ? "Завантаження..." : "Завантажити проєкт (.zip)"}
                </Button>
                <p className="mt-2 text-sm text-gray-500">
                  Версія 1.0.0, оновлено {new Date().toLocaleDateString()}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8 border-t border-gray-200">
          <p className="text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} Оцінка вартості товару. Усі права захищено.
          </p>
        </div>
      </footer>
    </div>
  );
}
