import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
 
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Interface definitions matching backend types
export interface Category {
  id: number;
  name: string;
  description: string | null;
}

export interface Supplier {
  id: number;
  name: string;
  rating: number;
  contactInfo: string | null;
}

export interface ProductEvaluation {
  name?: string;
  category: string;
  brand: string;
  year?: number | null;
  condition?: string;
  supplierId?: number | null;
  description?: string;
  features?: string[];
}

export interface EvaluationResult {
  estimatedPrice: string;
  comparisons: number;
}

export interface EvaluationHistory {
  id: number;
  productName: string | null;
  category: string;
  brand: string;
  year: number | null;
  condition: string | null;
  supplierId: number | null;
  description: string | null;
  estimatedPrice: number | null;
  comparisons: number;
  status: string;
  createdAt: string;
}

// API functions
export async function evaluateProduct(data: ProductEvaluation): Promise<EvaluationResult> {
  try {
    const response = await fetch('/api/evaluate', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(data),
    });

    if (!response.ok) {
      if (response.status === 404) {
        throw new Error('Не знайдено схожих товарів для оцінки');
      }
      
      try {
        const errorData = await response.json();
        
        if (errorData.details && Array.isArray(errorData.details)) {
          // Get validation errors
          const validationErrors = errorData.details.map((err: any) => 
            `${err.field}: ${err.message}`
          ).join(', ');
          throw new Error(`Помилка валідації: ${validationErrors}`);
        }
        
        throw new Error(errorData.message || errorData.error || 'Помилка оцінки товару');
      } catch (parseError) {
        if (parseError instanceof Error && parseError.message.includes('Помилка валідації')) {
          throw parseError;
        }
        throw new Error('Помилка оцінки товару');
      }
    }

    return await response.json();
  } catch (error) {
    console.error('Error in evaluateProduct:', error);
    throw error;
  }
}

export async function fetchCategories(): Promise<Category[]> {
  const response = await fetch('/api/categories');
  
  if (!response.ok) {
    throw new Error('Failed to fetch categories');
  }
  
  return await response.json();
}

export async function fetchSuppliers(): Promise<Supplier[]> {
  const response = await fetch('/api/suppliers');
  
  if (!response.ok) {
    throw new Error('Failed to fetch suppliers');
  }
  
  return await response.json();
}

export async function fetchConditions(): Promise<string[]> {
  const response = await fetch('/api/conditions');
  
  if (!response.ok) {
    throw new Error('Failed to fetch condition options');
  }
  
  return await response.json();
}

export async function fetchEvaluationHistory(): Promise<EvaluationHistory[]> {
  const response = await fetch('/api/evaluation-history');
  
  if (!response.ok) {
    throw new Error('Failed to fetch evaluation history');
  }
  
  return await response.json();
}

export async function downloadSourceCode(): Promise<void> {
  window.location.href = '/api/download-code';
}

// Helper functions
export function formatPrice(price: number | string | null): string {
  if (price === null) return 'N/A';
  
  const numPrice = typeof price === 'string' ? parseFloat(price) : price;
  return new Intl.NumberFormat('uk-UA', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2
  }).format(numPrice);
}

export function formatDate(date: string): string {
  return new Date(date).toLocaleString('uk-UA', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  });
}

export function getStatusBadge(status: string): string {
  const statusMap: Record<string, string> = {
    'success': 'bg-green-100 text-green-800 hover:bg-green-200',
    'no_matches': 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200',
    'error': 'bg-red-100 text-red-800 hover:bg-red-200',
  };
  
  return statusMap[status] || 'bg-gray-100 text-gray-800 hover:bg-gray-200';
}

export function getStatusText(status: string): string {
  const statusMap: Record<string, string> = {
    'success': 'Успішно',
    'no_matches': 'Немає збігів',
    'error': 'Помилка',
  };
  
  return statusMap[status] || status;
}
