import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import { CalendarIcon, BarChart4, GaugeCircle, Box, Tag } from "lucide-react";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { cn } from "@/lib/utils";
import { format } from "date-fns";
import { uk } from "date-fns/locale";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { ProductEvaluation, EvaluationResult, evaluateProduct, Category, Supplier } from "@/lib/utils";

interface ProductFormProps {
  onResult: (result: EvaluationResult) => void;
  onError: (message: string) => void;
  setLoading: (loading: boolean) => void;
}

export default function ProductForm({ onResult, onError, setLoading }: ProductFormProps) {
  const { toast } = useToast();
  
  // States for select options
  const [categories, setCategories] = useState<Category[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [conditionOptions, setConditionOptions] = useState<string[]>([]);
  
  // Form validation schema
  const formSchema = z.object({
    name: z.string().optional(),
    category: z.string().min(1, "Категорія є обов'язковою"),
    brand: z.string().min(1, "Бренд є обов'язковим"),
    year: z.number().optional().nullable(),
    condition: z.string().optional(),
    supplierId: z.coerce.number().optional().nullable(),
    description: z.string().optional(),
    features: z.array(z.string()).optional(),
  });

  type ProductFormValues = z.infer<typeof formSchema>;

  const form = useForm<ProductFormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      category: "",
      brand: "",
      year: null,
      condition: "",
      supplierId: null,
      description: "",
      features: [],
    },
  });

  // Fetch categories from API
  useEffect(() => {
    const fetchCategories = async () => {
      try {
        const response = await fetch('/api/categories');
        if (response.ok) {
          const data = await response.json();
          setCategories(data);
        } else {
          console.error('Failed to fetch categories');
        }
      } catch (error) {
        console.error('Error fetching categories:', error);
      }
    };

    const fetchSuppliers = async () => {
      try {
        const response = await fetch('/api/suppliers');
        if (response.ok) {
          const data = await response.json();
          setSuppliers(data);
        } else {
          console.error('Failed to fetch suppliers');
        }
      } catch (error) {
        console.error('Error fetching suppliers:', error);
      }
    };

    const fetchConditions = async () => {
      try {
        const response = await fetch('/api/conditions');
        if (response.ok) {
          const data = await response.json();
          setConditionOptions(data);
        } else {
          console.error('Failed to fetch conditions');
        }
      } catch (error) {
        console.error('Error fetching conditions:', error);
      }
    };

    fetchCategories();
    fetchSuppliers();
    fetchConditions();
  }, []);

  const onSubmit = async (data: ProductFormValues) => {
    try {
      setLoading(true);

      const result = await evaluateProduct(data as ProductEvaluation);
      onResult(result);
      
      toast({
        title: "Оцінку успішно виконано",
        description: `Орієнтовна ціна: $${result.estimatedPrice}`,
        variant: "default",
      });
    } catch (error) {
      onError(error instanceof Error ? error.message : "Помилка оцінки вартості");
      console.error("Evaluation error:", error);
      
      toast({
        title: "Помилка оцінки",
        description: error instanceof Error ? error.message : "Помилка оцінки вартості",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  // Helper to get current year
  const currentYear = new Date().getFullYear();
  const yearsList = Array.from({ length: 30 }, (_, i) => currentYear - i);
  
  // Helper to format condition display text
  const getConditionText = (key: string): string => {
    const conditionMap: Record<string, string> = {
      'new': 'Новий',
      'used': 'Вживаний',
      'refurbished': 'Відновлений',
      'damaged': 'Пошкоджений'
    };
    return conditionMap[key] || key;
  };
  
  // Helper to format condition badges
  const getConditionBadge = (condition: string) => {
    const badgeStyles: Record<string, string> = {
      'new': 'bg-green-100 text-green-800 hover:bg-green-200',
      'used': 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200',
      'refurbished': 'bg-blue-100 text-blue-800 hover:bg-blue-200',
      'damaged': 'bg-red-100 text-red-800 hover:bg-red-200',
    };
    
    return badgeStyles[condition] || 'bg-gray-100 text-gray-800 hover:bg-gray-200';
  };
  
  return (
    <Card className="bg-white rounded-lg shadow overflow-hidden">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
          <Tag className="h-5 w-5 mr-2 text-primary" />
          Дані товару
        </h2>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
            <FormField
              control={form.control}
              name="name"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Назва товару</FormLabel>
                  <FormControl>
                    <Input 
                      placeholder="Samsung Galaxy S20" 
                      {...field}
                      className="border-gray-300 focus:border-primary" 
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="category"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Категорія <span className="text-red-500">*</span></FormLabel>
                    <Select onValueChange={field.onChange} value={field.value}>
                      <FormControl>
                        <SelectTrigger className="border-gray-300">
                          <SelectValue placeholder="Оберіть категорію" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {categories.map((category) => (
                          <SelectItem key={category.id} value={category.name}>
                            {category.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="brand"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Бренд <span className="text-red-500">*</span></FormLabel>
                    <FormControl>
                      <Input 
                        placeholder="Samsung, Apple, Sony..." 
                        {...field} 
                        required 
                        className="border-gray-300 focus:border-primary"
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <FormField
                control={form.control}
                name="year"
                render={({ field }) => (
                  <FormItem className="flex flex-col">
                    <FormLabel>Рік виробництва</FormLabel>
                    <Popover>
                      <PopoverTrigger asChild>
                        <FormControl>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "pl-3 text-left font-normal border-gray-300",
                              !field.value && "text-muted-foreground"
                            )}
                          >
                            {field.value ? field.value : "Оберіть рік"}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </FormControl>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <div className="p-3 max-h-[300px] overflow-y-auto">
                          {yearsList.map((year) => (
                            <div 
                              key={year} 
                              className={cn(
                                "py-1 px-2 cursor-pointer rounded hover:bg-gray-100",
                                field.value === year && "bg-primary/10 font-medium"
                              )}
                              onClick={() => {
                                field.onChange(year);
                                document.querySelector('[data-radix-popper-content-wrapper]')?.dispatchEvent(
                                  new Event('pointerleave', { bubbles: true })
                                );
                              }}
                            >
                              {year}
                            </div>
                          ))}
                        </div>
                      </PopoverContent>
                    </Popover>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="condition"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Стан товару</FormLabel>
                    <Select onValueChange={field.onChange} value={field.value || ""}>
                      <FormControl>
                        <SelectTrigger className="border-gray-300">
                          <SelectValue placeholder="Оберіть стан товару" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        {conditionOptions.map((condition) => (
                          <SelectItem key={condition} value={condition}>
                            <div className="flex items-center">
                              <Badge variant="outline" className={cn("mr-2", getConditionBadge(condition))}>
                                {getConditionText(condition)}
                              </Badge>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>
            
            <FormField
              control={form.control}
              name="supplierId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Постачальник</FormLabel>
                  <Select 
                    onValueChange={(value) => field.onChange(value === "none" ? null : parseInt(value))} 
                    value={field.value?.toString() || "none"}
                  >
                    <FormControl>
                      <SelectTrigger className="border-gray-300">
                        <SelectValue placeholder="Оберіть постачальника" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      <SelectItem value="none">Не обрано</SelectItem>
                      {suppliers.map((supplier) => (
                        <SelectItem key={supplier.id} value={supplier.id.toString()}>
                          <div className="flex items-center justify-between w-full">
                            <span>{supplier.name}</span>
                            <span className="text-sm text-muted-foreground">
                              <span className="inline-flex items-center">
                                <BarChart4 className="h-3 w-3 mr-1 text-yellow-500" />
                                {supplier.rating}
                              </span>
                            </span>
                          </div>
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="description"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Опис товару</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="Детальний опис товару, технічні характеристики та інші особливості..." 
                      {...field} 
                      rows={3}
                      className="border-gray-300 focus:border-primary resize-none"
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <div className="bg-blue-50 rounded-lg p-4 mb-4 border border-blue-100">
              <div className="flex items-center mb-2">
                <GaugeCircle className="h-5 w-5 text-blue-500 mr-2" />
                <h3 className="text-sm font-medium text-blue-800">Критерії оцінки вартості:</h3>
              </div>
              <ul className="text-sm text-blue-700 space-y-1 pl-7 list-disc">
                <li>Категорія та бренд товару (обов'язкові поля)</li>
                <li>Рік виробництва та стан (додаткові критерії)</li>
                <li>Постачальник (впливає на кінцеву оцінку)</li>
              </ul>
            </div>

            <div className="flex justify-end">
              <Button 
                type="submit" 
                className="inline-flex items-center bg-gradient-to-r from-primary to-primary-dark hover:from-primary/90 hover:to-primary-dark/90 text-white font-medium px-6 py-2 rounded-md shadow-sm transition-all duration-200"
              >
                <Box className="h-5 w-5 mr-2" />
                Оцінити вартість
              </Button>
            </div>
          </form>
        </Form>
      </CardContent>
    </Card>
  );
}
