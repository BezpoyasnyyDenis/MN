import { useLocation } from "wouter";
import { cn } from "@/lib/utils";

interface NavigationProps {
  activeTab: "estimation" | "download";
}

export default function Navigation({ activeTab }: NavigationProps) {
  const [, navigate] = useLocation();

  return (
    <div className="border-b border-gray-200 mb-6">
      <nav className="-mb-px flex">
        <div 
          className={cn(
            "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm cursor-pointer mr-8",
            activeTab === "estimation" 
              ? "border-primary text-primary" 
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          )}
          onClick={() => navigate("/")}
        >
          Оцінка вартості
        </div>
        <div 
          className={cn(
            "whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm cursor-pointer",
            activeTab === "download" 
              ? "border-primary text-primary" 
              : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
          )}
          onClick={() => navigate("/download")}
        >
          Завантаження коду
        </div>
      </nav>
    </div>
  );
}
