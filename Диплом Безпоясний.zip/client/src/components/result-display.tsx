import { EvaluationResult, formatPrice } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, DollarSign, Info, Check, BarChart4, TrendingUp, ChevronUp } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Progress } from "@/components/ui/progress";
import { cn } from "@/lib/utils";

interface ResultDisplayProps {
  result: EvaluationResult | null;
  error: string | null;
  loading: boolean;
}

export default function ResultDisplay({ result, error, loading }: ResultDisplayProps) {
  // Визначення рівня впевненості оцінки на основі кількості порівнянь
  const getConfidenceLevel = (comparisons: number) => {
    if (comparisons >= 10) return { level: 'high', percent: 90, color: 'bg-green-500' };
    if (comparisons >= 5) return { level: 'medium', percent: 70, color: 'bg-blue-500' };
    if (comparisons >= 2) return { level: 'low', percent: 50, color: 'bg-yellow-500' };
    return { level: 'very low', percent: 30, color: 'bg-red-500' };
  };

  // Рівень впевненості для поточного результату
  const confidence = result ? getConfidenceLevel(result.comparisons) : null;
  
  return (
    <div className="space-y-6">
      <Card className="bg-white rounded-lg shadow-md hover:shadow-lg transition-all duration-300 overflow-hidden">
        <CardHeader className="bg-gradient-to-r from-primary/10 to-primary/5 pb-4">
          <CardTitle className="text-xl font-bold flex items-center text-gray-800">
            <DollarSign className="h-5 w-5 mr-2 text-primary" />
            Результат оцінки
          </CardTitle>
        </CardHeader>
        
        <CardContent className="p-6">
          {/* Initial state, no result or error */}
          {!result && !error && !loading && (
            <div className="py-6 text-center">
              <div className="bg-primary/5 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Info className="h-10 w-10 text-primary/70" />
              </div>
              <h3 className="text-lg font-medium text-gray-700 mb-2">Готові до оцінки</h3>
              <p className="text-gray-500 max-w-md mx-auto">
                Заповніть необхідні поля в формі та натисніть кнопку "Оцінити вартість"
              </p>
              
              <div className="mt-6 flex flex-col items-center space-y-3">
                <Badge variant="outline" className="px-3 py-1 text-xs bg-primary/5">
                  <Check className="h-3 w-3 mr-1" />
                  На основі реальних ринкових даних
                </Badge>
                <Badge variant="outline" className="px-3 py-1 text-xs bg-primary/5">
                  <Check className="h-3 w-3 mr-1" />
                  Аналіз схожих товарів у базі
                </Badge>
                <Badge variant="outline" className="px-3 py-1 text-xs bg-primary/5">
                  <Check className="h-3 w-3 mr-1" />
                  Врахування всіх критеріїв оцінки
                </Badge>
              </div>
            </div>
          )}

          {/* Loading state */}
          {loading && (
            <div className="flex flex-col items-center justify-center py-8">
              <div className="w-16 h-16 border-4 border-primary border-t-transparent rounded-full animate-spin"></div>
              <p className="mt-6 text-gray-600 font-medium">Оцінка вартості...</p>
              <p className="text-sm text-gray-500 mt-2">Пошук схожих товарів у базі даних</p>
            </div>
          )}
          
          {/* Success result */}
          {result && !loading && !error && (
            <div className="space-y-6">
              <div className="bg-gradient-to-r from-green-50 to-blue-50 p-6 rounded-lg border border-green-100">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="text-lg font-bold text-green-800 flex items-center">
                    <TrendingUp className="h-5 w-5 mr-2 text-green-600" />
                    Орієнтовна вартість
                  </h3>
                  <Badge variant="outline" className={cn(
                    result.comparisons > 5 ? "badge-success" : "badge-warning")}>
                    {result.comparisons} {getUkrainianPluralForm(result.comparisons, ["товар", "товари", "товарів"])}
                  </Badge>
                </div>
                
                <div className="text-4xl font-bold text-gradient mb-2">
                  ${result.estimatedPrice}
                </div>
                
                <Separator className="my-4" />
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1 text-sm">
                      <span className="font-medium">Точність оцінки:</span>
                      <span className="font-medium">{confidence?.level === 'high' ? 'Висока' : 
                        confidence?.level === 'medium' ? 'Середня' : 
                        confidence?.level === 'low' ? 'Низька' : 'Дуже низька'}</span>
                    </div>
                    <Progress value={confidence?.percent} className={cn("h-2", confidence?.color)} />
                  </div>
                  
                  <div className="bg-white rounded-md p-3 border border-gray-100">
                    <div className="flex items-center mb-1">
                      <BarChart4 className="h-4 w-4 mr-1.5 text-primary" />
                      <span className="text-sm font-medium">Статистика аналізу</span>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mt-2">
                      <div className="text-center p-2 bg-gray-50 rounded">
                        <div className="text-xs text-gray-600">Схожих товарів</div>
                        <div className="font-semibold text-gray-900">{result.comparisons}</div>
                      </div>
                      <div className="text-center p-2 bg-gray-50 rounded">
                        <div className="text-xs text-gray-600">Середня ціна</div>
                        <div className="font-semibold text-gray-900">${result.estimatedPrice}</div>
                      </div>
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 italic">
                    * Ціна є орієнтовною і може відрізнятись залежно від конкретних умов на ринку
                  </p>
                </div>
              </div>
            </div>
          )}
          
          {/* Error result */}
          {error && !loading && (
            <div className="bg-red-50 text-red-700 p-5 rounded-lg border border-red-100">
              <div className="flex items-start">
                <AlertCircle className="h-6 w-6 mr-3 mt-0.5 flex-shrink-0 text-red-500" />
                <div>
                  <h3 className="font-semibold text-lg mb-1">
                    {error.includes('Не знайдено схожих товарів') 
                      ? 'Товари не знайдено' 
                      : error.includes('Помилка валідації') 
                        ? 'Помилка у заповненні форми'
                        : 'Помилка оцінки'
                    }
                  </h3>
                  <p className="text-red-600">{error}</p>
                  
                  <div className="mt-3 p-3 bg-red-100/50 rounded text-sm">
                    <p className="font-medium">Рекомендації:</p>
                    {error.includes('Не знайдено схожих товарів') && (
                      <ul className="list-disc ml-5 mt-1 space-y-1">
                        <li>Спробуйте вибрати більш поширену категорію товару</li>
                        <li>Перевірте правопис бренду (можливо такого бренду немає в базі)</li>
                        <li>Зменшіть кількість фільтрів — зніміть вибір року, стану або постачальника</li>
                        <li>Спробуйте ввести іншу модель товару</li>
                      </ul>
                    )}
                    
                    {error.includes('Помилка валідації') && (
                      <ul className="list-disc ml-5 mt-1 space-y-1">
                        <li>Перевірте, чи правильно заповнені всі обов'язкові поля (позначені *)</li>
                        <li>Категорія та бренд є обов'язковими полями</li>
                        <li>Переконайтеся, що у полі "Рік" вказано коректне число</li>
                      </ul>
                    )}
                    
                    {(!error.includes('Не знайдено схожих товарів') && !error.includes('Помилка валідації')) && (
                      <ul className="list-disc ml-5 mt-1 space-y-1">
                        <li>Перевірте правильність введених критеріїв</li>
                        <li>Спробуйте вибрати іншу категорію товару</li>
                        <li>Зменшіть кількість фільтрів для ширшого пошуку</li>
                        <li>Спробуйте перезавантажити сторінку і повторити запит</li>
                      </ul>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
      
      {/* Tips box */}
      <Card className="bg-white shadow-sm hover:shadow transition-all duration-300">
        <CardContent className="p-6">
          <h3 className="flex items-center text-primary font-medium mb-3">
            <Info className="h-5 w-5 mr-2" />
            Критерії оцінювання
          </h3>
          <ul className="text-sm text-gray-700 space-y-3">
            <li className="flex items-start">
              <div className="mt-0.5">
                <ChevronUp className="h-4 w-4 text-success mr-2" />
              </div>
              <span><span className="font-medium">Категорія та бренд</span> - основні критерії, що визначають базову вартість товару. <span className="text-primary-dark font-medium">Обов'язкові поля.</span></span>
            </li>
            <li className="flex items-start">
              <div className="mt-0.5">
                <ChevronUp className="h-4 w-4 text-success mr-2" />
              </div>
              <span><span className="font-medium">Рік виробництва</span> - значно впливає на вартість, особливо для техніки та автомобілів.</span>
            </li>
            <li className="flex items-start">
              <div className="mt-0.5">
                <ChevronUp className="h-4 w-4 text-success mr-2" />
              </div>
              <span><span className="font-medium">Стан товару</span> - від "нового" до "пошкодженого", коригує ціну відносно середньоринкової.</span>
            </li>
            <li className="flex items-start">
              <div className="mt-0.5">
                <ChevronUp className="h-4 w-4 text-success mr-2" />
              </div>
              <span><span className="font-medium">Постачальник</span> - рейтинг постачальника може впливати на надійність оцінки.</span>
            </li>
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}

// Допоміжна функція для правильного відмінювання кількості товарів
function getUkrainianPluralForm(count: number, forms: [string, string, string]): string {
  const remainder100 = Math.abs(count) % 100;
  const remainder10 = remainder100 % 10;
  
  if (remainder100 > 10 && remainder100 < 20) return forms[2];
  if (remainder10 === 1) return forms[0];
  if (remainder10 > 1 && remainder10 < 5) return forms[1];
  return forms[2];
}
