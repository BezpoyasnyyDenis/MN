import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  BarChart4, 
  ClipboardList, 
  Calendar as CalendarIcon, 
  Tag, 
  Briefcase,
  AlertCircle
} from "lucide-react";
import { fetchEvaluationHistory, EvaluationHistory, formatPrice, formatDate, getStatusBadge, getStatusText } from "@/lib/utils";
import { cn } from "@/lib/utils";

export default function EvaluationHistoryComponent() {
  const [history, setHistory] = useState<EvaluationHistory[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const loadHistory = async () => {
      try {
        setLoading(true);
        const data = await fetchEvaluationHistory();
        setHistory(data);
        setError(null);
      } catch (err) {
        console.error("Failed to load evaluation history:", err);
        setError("Помилка завантаження історії оцінювань");
      } finally {
        setLoading(false);
      }
    };

    loadHistory();
  }, []);

  if (loading) {
    return (
      <Card className="w-full shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl flex items-center">
            <ClipboardList className="h-5 w-5 mr-2" />
            Історія оцінювань
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex justify-center items-center py-8">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (error) {
    return (
      <Card className="w-full shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl flex items-center">
            <ClipboardList className="h-5 w-5 mr-2" />
            Історія оцінювань
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="bg-red-50 text-red-800 p-4 rounded-md flex items-start">
            <AlertCircle className="h-5 w-5 mr-2 mt-0.5 flex-shrink-0" />
            <p>{error}</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  if (history.length === 0) {
    return (
      <Card className="w-full shadow-sm">
        <CardHeader>
          <CardTitle className="text-xl flex items-center">
            <ClipboardList className="h-5 w-5 mr-2" />
            Історія оцінювань
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-gray-500">
            <ClipboardList className="h-12 w-12 mx-auto mb-3 text-gray-400" />
            <p>У вас ще немає історії оцінювань</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl flex items-center">
          <ClipboardList className="h-5 w-5 mr-2" />
          Історія оцінювань
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea className="h-[400px]">
          <Table>
            <TableHeader className="bg-gray-50 sticky top-0">
              <TableRow>
                <TableHead className="w-[180px]">Товар</TableHead>
                <TableHead>Категорія</TableHead>
                <TableHead>Деталі</TableHead>
                <TableHead className="text-right">Ціна</TableHead>
                <TableHead className="text-right">Статус</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {history.map((item) => (
                <TableRow key={item.id}>
                  <TableCell className="font-medium">
                    <div className="flex flex-col">
                      <span>{item.productName || "Без назви"}</span>
                      <span className="text-sm text-muted-foreground">{item.brand}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center">
                      <Tag className="h-3.5 w-3.5 mr-1.5 text-primary" />
                      {item.category}
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex flex-col gap-1 text-sm">
                      {item.year && (
                        <div className="flex items-center">
                          <CalendarIcon className="h-3.5 w-3.5 mr-1.5 text-gray-500" />
                          {item.year}
                        </div>
                      )}
                      {item.condition && (
                        <div className="flex items-center">
                          <div className="h-2 w-2 rounded-full bg-blue-500 mr-1.5" />
                          {item.condition}
                        </div>
                      )}
                      {item.supplierId && (
                        <div className="flex items-center">
                          <Briefcase className="h-3.5 w-3.5 mr-1.5 text-gray-500" />
                          ID: {item.supplierId}
                        </div>
                      )}
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex flex-col items-end">
                      <span className="font-medium">{formatPrice(item.estimatedPrice)}</span>
                      <span className="text-xs text-muted-foreground flex items-center">
                        <BarChart4 className="h-3 w-3 mr-1" />
                        {item.comparisons} порівнянь
                      </span>
                    </div>
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex flex-col items-end gap-1">
                      <Badge variant="outline" className={cn(getStatusBadge(item.status))}>
                        {getStatusText(item.status)}
                      </Badge>
                      <span className="text-xs text-muted-foreground">{formatDate(item.createdAt)}</span>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}